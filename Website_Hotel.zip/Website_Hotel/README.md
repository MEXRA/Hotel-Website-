Hotel Website Example.
